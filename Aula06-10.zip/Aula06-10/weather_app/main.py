import requests
from pprint import pprint

API_key = "40f808d7b5dc4b4c98f224417262909"
API_link = "https://api.weatherapi.com/v1/current.json"

#__________________________________________________________________________________________
#Escolha das informações pedidas para a API
lang = input("Lingua desejada para o retorno das informações. (pt / fr / en / de / isto):")
q = input("Local desejado para realizar a previsão")
print("="*36)
#__________________________________________________________________________________________

params = {
    "key": API_key,
    "q": q,
    "lang":lang,
}

response = requests.get(API_link, params=params)

code = response.status_code

if code == 200:
    dados = response.json()
    print("Busca concluida.")
    temperatura = dados["current"]["temp_c"]
    descricao = dados["current"]["condition"]["text"]

    print(f"Temperatura: {temperatura} °C")
    print(f"Condição: {descricao}")
    
elif code >= 400:
    response_erro = response.json()
    
    codigo = response_erro['code']
    mensagem = response_erro['message']

    print(f"Código do erro: {codigo} ")
    print(f"Motivo do erro: {mensagem}")
else:
    print("Deu preguiça de procurar, mas acho que o que você quer tá em outro lugar ;)")

    